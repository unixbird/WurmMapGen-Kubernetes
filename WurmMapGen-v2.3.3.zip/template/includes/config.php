<?php
$conf_rmi_host = 'localhost';
$conf_rmi_port = '8080';
?>
